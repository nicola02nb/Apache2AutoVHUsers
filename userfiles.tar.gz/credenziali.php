<?php
	$user="";
	$password="";
	$database="";
	$host="";
?>
