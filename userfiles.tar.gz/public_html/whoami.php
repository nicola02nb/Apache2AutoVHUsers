<?php echo exec('whoami'); ?> 
